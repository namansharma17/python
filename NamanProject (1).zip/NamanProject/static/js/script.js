const clockEl = document.getElementById('clock');
const dateEl = document.getElementById('date');
const timezoneSelect = document.getElementById('timezone');
const toggleThemeBtn = document.getElementById('toggle-theme');

let timeZone = 'local';
const DateTime = luxon.DateTime;

function updateClock() {
    let now;
    if (timeZone === 'local') {
        now = DateTime.local();
    } else {
        now = DateTime.now().setZone(timeZone);
    }

    clockEl.textContent = now.toFormat('HH:mm:ss');
    dateEl.textContent = now.toFormat('cccc, dd LLL yyyy');
}

timezoneSelect.addEventListener('change', () => {
    timeZone = timezoneSelect.value;
});

toggleThemeBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

setInterval(updateClock, 1000);
updateClock();
